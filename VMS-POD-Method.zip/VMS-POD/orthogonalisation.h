#include <iostream>
#include "personal-copy-eigen-3.4.0/Eigen/Dense" 

using namespace Eigen;

//This function provides a matrix with an ON basis of L^R. 
MatrixXd resolved_ON(MatrixXd PODbasis,int R, MatrixXd B){
    MatrixXd result_ON=MatrixXd::Zero(PODbasis.rows(),R);
    double divisor;
    for(int i=0; i<R; i++){
        result_ON(all,i)=PODbasis(all,i);
        int j=0;
        while(j<i){
            result_ON(all,i)=result_ON(all,i)-(result_ON(all,j).transpose()*B*PODbasis(all,i))*result_ON(all,j);
            j=j+1;
        }
        divisor=sqrt(((result_ON(all,i)).transpose()*B*result_ON(all,i)));
        if (divisor < 1e-12){   // Avoid division by zero
            std::cerr << "Warning: risk to divide by zero" << std::endl;
            continue;
        }
        result_ON(all,i)=result_ON(all,i)/divisor;
    }
    return result_ON;
}