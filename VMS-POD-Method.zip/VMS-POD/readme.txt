*This is the implementation part of the Master thesis: "Reduced Order Modeling with a Variational Multiscale Method" by Clara Merten, submitted in March 2025 to obtain the Master of Science in Mathematics at the 'Freie Universität Berlin'. The thesis was prepared under the supervision of Prof. Volker John.*

The code applies the VMS-POD procedure described in thedis to the example problem of section 7.2.

Compile and run the file VMS-POD-P1.cpp to get the results for linear FEs and VMS-POD-P2.cpp to get the results for quadratic FEs.
Both output the L^2 average error and create a csv file ('VMS-POD-P1-results.csv', 'VMS-POD-P2-results.csv') with the results matrix.

The variables M, N, r, R, epsylon and epsylon_+ are set up in the first lines of the main function. If necessary, you can change them there.
We start with the values: N=500, r=40, R=20, epsylon=1e-10, epsylon_+= 4/M. M differes in 'VMS-POD-P1-results.csv' and 'VMS-POD-P2-results.csv'. 
For P1 we have M=500, for P2 we have M=250.

The hadder files 'name.h' contain functions for the main, which do not directly concern the VMS-POD procedure.

To apply this to other one-dimensional problems you would need to add the matrix C and adjust N_k, F and epsylon.

A personal copy of Eigen 3.4.0 is included (see: https://eigen.tuxfamily.org) 
